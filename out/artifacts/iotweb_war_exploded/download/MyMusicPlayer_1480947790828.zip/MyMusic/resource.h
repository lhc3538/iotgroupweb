//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDD_MAIN                        101
#define IDC_OK                          1000
#define IDC_LIST3                       1005
#define IDC_STATIC1                     1006
#define IDC_EDIT1                       1007
#define IDC_EDIT2                       1008
#define IDC_UP                          1009
#define IDC_PAUSE                       1010
#define IDC_PLAY                        1011
#define IDC_CONTINUE                    1012
#define IDC_STOP                        1013
#define IDC_DOWN                        1014
#define IDC_ADD                         1015
#define IDC_DELETE                      1016
#define IDC_ABOUT                       1017
#define IDC_NEXT                        1025
#define IDC_LAST                        1026
#define IDC_EDIT4                       1028
#define IDC_EDIT3                       1029
#define IDC_X                           1030
#define IDC_EDIT5                       1032

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1033
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
